//
//  SecondViewController.h
//  TabReader
//
//  Created by spadix on 5/3/11.
//

#import <UIKit/UIKit.h>

@interface ResultsViewController
    : UIViewController
{
}

@property (nonatomic, retain) IBOutlet UIImageView *resultImage;
@property (nonatomic, retain) IBOutlet UITextView *resultText;

@end
