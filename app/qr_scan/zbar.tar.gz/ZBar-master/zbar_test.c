#include <stdio.h>
#include <malloc.h>
#include <zbar.h>

static char *img = NULL;

static void read_img()
{
	FILE *fYuv = fopen("dd.yuv", "rb");
	if(!fYuv) return;
	img = malloc(640*360);
	fread(img, 1, 640*360, fYuv);
	fclose(fYuv);
}


int main()
{
	zbar_image_t *zimg = NULL;
	zbar_image_scanner_t *zscn = zbar_image_scanner_create();
	int ret = 0;
	if(zscn == NULL) return -1;

	read_img();

	if(!img) {
		printf("no image!");
		return -1;
	}

	zbar_image_scanner_set_config(zscn, 0, ZBAR_CFG_ENABLE, 1);

	zbar_image_scanner_set_config(zscn, 0, ZBAR_CFG_X_DENSITY, 1);
	zbar_image_scanner_set_config(zscn, 0, ZBAR_CFG_Y_DENSITY, 1);

	zimg = zbar_image_create();

	zbar_image_set_size(zimg, 640, 360);

	zbar_image_set_format(zimg, zbar_fourcc('G','R','E','Y'));

	zbar_image_set_data(zimg, img, 640*360, NULL);

	ret = zbar_scan_image(zscn, zimg);

	printf("scan ret:%d\n", ret);

	const zbar_symbol_t *symbol = zbar_image_first_symbol(zimg);
    for(; symbol; symbol = zbar_symbol_next(symbol)) {
        /* do something useful with results */
        zbar_symbol_type_t typ = zbar_symbol_get_type(symbol);
        const char *data = zbar_symbol_get_data(symbol);
        printf("decoded %s symbol \"%s\"\n",
               zbar_get_symbol_name(typ), data);
    }
	
	return 0;
}

